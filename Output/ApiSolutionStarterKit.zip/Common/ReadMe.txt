﻿﻿Contains "framework-ish" fuctionality not specific to the API or the database.
Examples could be interface for using AutoMapper library (if being used in the solution) that may be used by two or more layers.
If there is no need for this layer within the solution it can be removed.
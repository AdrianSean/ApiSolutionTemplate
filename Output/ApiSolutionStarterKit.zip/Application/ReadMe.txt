﻿Facade layer that performs use case type functionality.
The API layer should only need to call into this once for a request to perform a task.